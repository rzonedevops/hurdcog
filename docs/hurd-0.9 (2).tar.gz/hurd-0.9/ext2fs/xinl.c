#define EXT2FS_DEFINE_EI
#include "ext2fs.h"
