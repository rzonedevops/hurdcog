# Formatting source code

We use shfmt to format our shell scripts. You can run shfmt -i 2 -ci *.sh to format all shell scripts in the repository.
