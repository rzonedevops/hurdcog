extern AuthInfo*	_fauth_proxy(int fd, AuthRpc *rpc, AuthGetkey *getkey, char *params);
