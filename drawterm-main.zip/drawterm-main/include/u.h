#include "dtos.h"

/* avoid name conflicts */
#undef accept
#undef listen

/* sys calls */
#undef bind
#undef chdir
#undef close
#undef create
#undef dup
#undef export
#undef fstat
#undef fwstat
#undef mount
#undef open
#undef start
#undef read
#undef remove
#undef seek
#undef stat
#undef write
#undef wstat
#undef unmount
#undef pipe
