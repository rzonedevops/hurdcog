#include <u.h>
#include <libc.h>
#include <draw.h>
#include <memdraw.h>

int
iprint(char *fmt,...)
{
	USED(fmt);
	return -1;
}

