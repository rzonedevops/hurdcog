#include <u.h>
#include <libc.h>
#include <draw.h>
#include <memdraw.h>

int
hwdraw(Memdrawparam *p)
{
	USED(p);
	return 0;	/* could not satisfy request */
}

